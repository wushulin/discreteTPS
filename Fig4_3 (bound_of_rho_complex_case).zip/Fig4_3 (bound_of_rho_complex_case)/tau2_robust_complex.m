% tau2_robust_complex.m  （保持不变）
function val = tau2_robust_complex(z, a)
    global J theta
    [x, y, s, U, ~, delta, ~] = get_params_complex(z, a);

    if isinf(x) || isnan(x) || abs(delta) < 1e-300
        val = 1; return;
    end

    if theta == 0.5
        s_eff = s;
    else
        s_eff = conj(s);
    end
    s_tilde = s_eff * (x + y) - 1;

    C = s * x - s_tilde;
    D = s * y - s_tilde;
    g = x - s;
    h = y - s;

    E = - x^J * y^(J-1) * h;
    G = x^(2*J-1) * g;

    if abs(E + G) < 1e-300
        val = 0; return;
    end

    a12 = (C * E + D * G) / delta;
    b21 = U / (E + G);

    val = sqrt(abs(a12 * b21));
end