clc;
clear;
global J theta N nu 
J=25;
theta=2/2;
nu=1e-2;
dt=1e-3;
a=dt^2/nu;

x=1.01;
d=180;
zz1=[0,x.^(-800:d)];
zz2=unique([-x.^(d:-1:-800),x.^(-800:d)]);
 
z1_num=length(zz1);
z2_num=length(zz2);
tau_1=zeros(z1_num,z2_num);
tau_2=zeros(z1_num,z2_num);
for j1=1:z1_num
  for j2=1:z2_num
      z=zz1(j1)+1i*zz2(j2);
      tau_1(j1,j2)= tau1_robust_complex(z, a);
      tau_2(j1,j2)= tau2_robust_complex(z, a);
  end
end
 
 
 rho_bound=zeros(z1_num,z2_num);
if N==2
    rho_bound=abs(tau_2);
elseif N==3 
    for j1=1:z1_num
        for j2=1:z2_num
            rho_bound(j1,j2)=max(sqrt(abs(tau_2(j1,j2).*(tau_2(j1,j2)-tau_1(j1,j2)))),sqrt(abs(tau_2(j1,j2).*(tau_2(j1,j2)-tau_1(j1,j2)))));
        end
    end
elseif N==4 
    for j1=1:z1_num
        for j2=1:z2_num
            r=tau_1(j1,j2)/tau_2(j1,j2);
            u = roots([1, 0, -2*r^2, -r^4]) + 1;
            rho_bound(j1,j2)=abs(tau_2(j1,j2))*max(sqrt(abs(u)));
        end
    end
else
    for j1=1:z1_num
        for j2=1:z2_num
            rho_bound(j1,j2) = abs(tau_1(j1,j2))+abs(tau_2(j1,j2)); 
        end
    end
end
 

% ========== ??1: |tau_1| ==========
figure(1);  
tau12_plot = rho_bound;
tau12_plot(rho_bound >1) =NaN;
 
contourf(zz1, zz2, transpose(tau12_plot), 30, 'LineStyle', 'none');
set(gca,'FontSize',18);

colorbar;
colormap(parula);
ylabel('Im$(z)$','Interpreter','latex','FontSize',23);
xlabel('Re$(z)$','Interpreter','latex','FontSize',23);
if nu==1e-2
    title(['$\theta=',num2str(theta),' ~(\nu=1e-2)$'],'Interpreter','latex','FontSize',23); 
else
     title(['$\theta=',num2str(theta),' ~(\nu=1e-7)$'],'Interpreter','latex','FontSize',23); 
end

cmap = colormap;                 
cmap(1, :) = [0, 0, 0.65];      
colormap(cmap);                
set(gca, 'Color', 'w');  
axis tight;
xlim([min(zz1),max(zz1)]);
ylim([min(real(zz2)),max(real(zz2))]);
set(gca,'xtick',0:5);
set(gca,'ytick',-5:5);
 