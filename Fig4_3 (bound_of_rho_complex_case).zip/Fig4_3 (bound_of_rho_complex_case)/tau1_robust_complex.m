% tau1_robust_complex.m  （保持不变）
function val = tau1_robust_complex(z, a)
    [x, y, s, ~, ~, delta, ~] = get_params_complex(z, a);

    if isinf(x) || isnan(x) || abs(delta) < 1e-300
        val = 0; return;
    end

    val = s * (x - y) / delta;
end