% this is the main code for plotting \rho (R) and its bound  
% |tau_1| + |tau_2| in the complex case
clc;
clear;
global J theta N alpha nu
imag_c = 1;
theta  = 1/2;        % theta={0, 0.5, 1}
alpha  = 1;
nu     = 1e-4;       %  penalty parameter
J      = 25;
N      = 5; 
dt     = 1e-3;
if theta == 0
      zz0 = unique([1.01.^(-600:0),1.005.^(0:1400)]);
      zz  = unique(min(zz0,1));
      if nu == 1e-7
        zz = unique(min(zz0,1.5));
      end
      zz(zz == 1) = [];
      zz = zz*(1+imag_c*1i);
elseif theta == 1 
      zz = 1.05.^(-160:150);
      zz = zz*(1+imag_c*1i);
else 
      zz = 1.05.^(-160:150);
      zz = zz*(1+imag_c*1i);
end

a = dt^2*alpha*(1/nu); 
z_num = length(zz);
tau_1 = zeros(1,z_num);
tau_2 = zeros(1,z_num);
tau12_abs = zeros(1,z_num);
rho_R = zeros(1,z_num);
R = zeros(2*N,2*N);
Dis = toeplitz([0;1;zeros(N-2,1)],zeros(1,N));

for jz = 1:z_num
  z = zz(jz);
  tau_1(jz) = tau1_robust_complex(z, a);
  tau_2(jz) = tau2_robust_complex(z, a);

  % ---- 正确的 R 矩阵构造 ----
  [x, y, s, ~, ~, delta, ~] = get_params_complex(z, a);

  if theta == 0.5
      s_eff = s;
  else
      s_eff = conj(s);
  end
  s_tilde = s_eff*(x + y) - 1;

  g = x - s;   % 边界用 s_raw
  h = y - s;

  D  = [1, 1; x^(J-1)*g, y^(J-1)*h];
  El = [x^J, y^J; 0, 0];
  Er = [0, 0; s*x - s_tilde, s*y - s_tilde];

  A = D \ Er;
  B = D \ El;

  R = kron(Dis, B) + kron(Dis', A);
  rho_R(jz) = max(abs(eig(R)));
end

if N == 2
    tau12_abs = abs(tau_2);
elseif N == 3
    tau12_abs = tau_1;
    for jz = 1:z_num 
        tau12_abs(jz) = max(sqrt(abs(tau_2(jz).*(tau_2(jz)+tau_1(jz)))), ...
                            sqrt(abs(tau_2(jz).*(tau_2(jz)-tau_1(jz)))));
    end
elseif N == 4
    tau12_abs = tau_1;
    for jz = 1:z_num 
        r = tau_1(jz)/tau_2(jz);
        u = roots([1, 0, -2*r^2, -r^4]) + 1;
        tau12_abs(jz) = abs(tau_2(jz))*max(sqrt(abs(u)));
    end
else
     for jz = 1:z_num 
        tau12_abs(jz) = abs(tau_1(jz)) + abs(tau_2(jz));    
     end
end

figure(1);  
if nu == 1e-1
    semilogx(real(zz),rho_R,'r-',real(zz),tau12_abs,'k--','LineWidth',1.5,'MarkerSize',13);
    %hold on;
else
    semilogx(real(zz),rho_R,'b-',real(zz),tau12_abs,'k-.','LineWidth',1.5,'MarkerSize',13);
    hold off;
end
set(gca,'FontSize',19);
xlabel('$z (=\Delta t\lambda)$','Interpreter','latex','FontSize',22);
title(['$\theta=',num2str(theta),'$'],'Interpreter','latex','FontSize',22); 
leg = legend(['$\rho(\mathbf{R})$ for $\nu=',num2str(nu),'$'],['bound for $\nu=',num2str(nu),'$']);
set(leg,'fontsize',16,'interpreter','latex');
xlim([min(real(zz)),max(real(zz))]);
set(gca,'xtick',10.^(-3:3)); 