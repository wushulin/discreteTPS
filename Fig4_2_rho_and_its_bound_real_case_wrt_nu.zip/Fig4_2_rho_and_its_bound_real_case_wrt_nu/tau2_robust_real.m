% tau2_robust_real.m
function val = tau2_robust_real(z, a)
    global J
    [x, y, s, ~, ~, delta, ~] = get_params_real(z, a);

    if isinf(x) || isnan(x) || abs(delta) < 1e-300
        val = 1; return;
    end

    g = x - s;
    h = y - s;

    val = sqrt(abs(g*h*(x^(2*J) - 1)*(1 - y^(2*J)))) / abs(delta);
end