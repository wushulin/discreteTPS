% get_params_real.m
function [x, y, s, U, V, delta, P] = get_params_real(z, a)
    global theta J
    switch theta
        case 0
            eta = 1 - z;
            mu  = 2 - 2*z + z^2 + a;
            s   = (1 - z)/(1 + a);
        case 0.5
            eta = 1 - 0.25*(z^2 + a);
            mu  = 2 + 0.5*(z^2 + a);
            s   = (4 - z^2 - a) / (4 + 4*z + z^2 + a);
        case 1
            eta = 1 + z;
            mu  = 2 + 2*z + z^2 + a;
            s   = 1/(1 + z);
        otherwise
            error('theta must be 0, 0.5 or 1');
    end

    if abs(eta) < 1e-14
        x = Inf; y = 0; U = Inf; V = Inf; delta = Inf;
        P = zeros(1, J+1); P(1) = 0; P(2) = 1;
        return;
    end

    disc = mu^2 - 4*eta^2;
    r = sqrt(disc);
    r1 = (mu + r) / (2*eta);
    r2 = (mu - r) / (2*eta);

    if abs(r1) >= abs(r2)
        x = r1; y = r2;
    else
        x = r2; y = r1;
    end

    P = zeros(1, J+1); P(1) = 0; P(2) = 1;
    T = x + y;   S = x * y;
    for n = 3:J+1
        P(n) = T*P(n-1) - S*P(n-2);
    end

    U = (x - y) * P(J+1);
    V = (x - y) * P(J);
    delta = U - s * V;
end