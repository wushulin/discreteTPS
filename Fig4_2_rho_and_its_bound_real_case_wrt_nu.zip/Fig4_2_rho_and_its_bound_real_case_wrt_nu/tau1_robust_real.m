% tau1_robust_real.m
function val = tau1_robust_real(z, a)
    [x, y, s, ~, ~, delta, ~] = get_params_real(z, a);

    if isinf(x) || isnan(x) || abs(delta) < 1e-300
        val = 0; return;
    end

    val = s * (x - y) / delta;
end