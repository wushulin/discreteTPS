% main_code_fig42.m
clc;
clear;
close all
global J theta N alpha nu
J      = 25;
N      = 32; 
alpha  = 1;
dt     = 1e-3;
nu_vec = 1.15.^(-116:0);
flag_BC = 1;
if flag_BC == 1
    z_min = 0.0047;
    z_max = 1.9613;
else
    z_min = 0;
    z_max = 1.9610;
end
z_num = 30;
zz = linspace(z_min, z_max, z_num);
nu_num = length(nu_vec);
theta_vec = [0, 0.5, 1];
rho_max = zeros(length(theta_vec), nu_num);
bound_max = zeros(length(theta_vec), nu_num);
R = zeros(2*N,2*N);
Dis = toeplitz([0;1;zeros(N-2,1)],zeros(1,N));
for it = 1:length(theta_vec)
    theta = theta_vec(it);
    for jnu = 1:nu_num
        nu = nu_vec(jnu);
        a = dt^2*alpha/nu;
        rho_temp = zeros(1,z_num);
        bound_temp = zeros(1,z_num);
        for jz = 1:z_num
            z = zz(jz);
            tau1 = tau1_robust_real(z, a);
            tau2 = tau2_robust_real(z, a);
            bound_temp(jz) = sqrt(abs(tau1)^2 + abs(tau2)^2);
            [x, y, s, ~, ~, delta, ~] = get_params_real(z, a);
            s_eff = s;
            s_tilde = s_eff*(x + y) - 1;
            g = x - s;
            h = y - s;
            c1 = s*x - s_tilde;
            c2 = s*y - s_tilde;
            cc = x^(J-1)*g;
            dd = y^(J-1)*h;
            det_D = dd - cc;
            if abs(det_D) < 1e-300
                D  = [1, 1; x^(J-1)*g, y^(J-1)*h];
                El = [x^J, y^J; 0, 0];
                Er = [0, 0; s*x - s_tilde, s*y - s_tilde];
                A = D \ Er;
                B = D \ El;
            else
                A = [-c1, -c2; c1, c2] / det_D;
                B = [dd*x^J, dd*y^J; -cc*x^J, -cc*y^J] / det_D;
            end
            R = kron(Dis, B) + kron(Dis', A);
            rho_temp(jz) = max(abs(eig(R)));
        end
        rho_max(it, jnu) = max(rho_temp);
        bound_max(it, jnu) = max(bound_temp);
    end
end
figure(1);
hold on;
for it = 1:length(theta_vec)
    if theta_vec(it) == 0
        semilogx(nu_vec, rho_max(it,:), 'r-', 'LineWidth', 1.5);
        semilogx(nu_vec, bound_max(it,:), 'r-.', 'LineWidth', 1.5);
    elseif theta_vec(it) == 0.5
        semilogx(nu_vec, rho_max(it,:), 'k-', 'LineWidth', 1.5);
        semilogx(nu_vec, bound_max(it,:), 'k-.', 'LineWidth', 1.5);
    else
        semilogx(nu_vec, rho_max(it,:), 'b-', 'LineWidth', 1.5);
        semilogx(nu_vec, bound_max(it,:), 'b-.', 'LineWidth', 1.5);
    end
end
set(gca, 'XScale', 'log')
hold off;
set(gca,'FontSize',19);
xlabel('$\nu$','Interpreter','latex','FontSize',22);
set(gca,'xtick',10.^(-7:0));
xlim([1e-7,1]);
ylim([0.3,1.5]);
set(gca,'ytick',0.3:0.1:1.5);
if flag_BC == 1
    title('Dirichlet BCs','Interpreter','latex','FontSize',22);
else
    title('Periodic BCs','Interpreter','latex','FontSize',22);
end
 grid on; 
