% this is the main code for plotting \rho (R) and its bound
% sqrt(|tau_1|^2 + |tau_2|^2) in the real case
clc;
clear;
global J theta N alpha nu
theta  = 0/2;        % theta={0, 0.5, 1}
alpha  = 1;
nu     = 1e-1;       %  penalty parameter
J      = 25;
N      = 32; 
dt     = 1e-3;
if theta == 0
      zz0 = unique([1.01.^(-600:0),1.005.^(0:1400)]);
      zz  = unique(min(zz0,1));
      if nu == 1e-7
        zz = unique(min(zz0,1.5));
      end
      zz(zz == 1) = [];
elseif theta == 1 
      zz = 1.05.^(-160:150);
else 
      zz = 1.05.^(-160:150);
end

a = dt^2*alpha*(1/nu); 
z_num = length(zz);
tau_1 = zeros(1,z_num);
tau_2 = zeros(1,z_num);
tau12_abs = zeros(1,z_num);
rho_R = zeros(1,z_num);
R = zeros(2*N,2*N);
Dis = toeplitz([0;1;zeros(N-2,1)],zeros(1,N));

for jz = 1:z_num
  z = zz(jz);
  tau_1(jz) = tau1_robust_real(z, a);
  tau_2(jz) = tau2_robust_real(z, a);

  [x, y, s, ~, ~, delta, ~] = get_params_real(z, a);

  s_eff = s;
  s_tilde = s_eff*(x + y) - 1;

  g = x - s;
  h = y - s;

  D  = [1, 1; x^(J-1)*g, y^(J-1)*h];
  El = [x^J, y^J; 0, 0];
  Er = [0, 0; s*x - s_tilde, s*y - s_tilde];

  c1 = s*x - s_tilde;
  c2 = s*y - s_tilde;
  cc = x^(J-1)*g;
  dd = y^(J-1)*h;
  det_D = dd - cc;

  if abs(det_D) < 1e-300
      A = D \ Er;
      B = D \ El;
  else
      A = [-c1, -c2; c1, c2] / det_D;
      B = [dd*x^J, dd*y^J; -cc*x^J, -cc*y^J] / det_D;
  end

  R = kron(Dis, B) + kron(Dis', A);
  rho_R(jz) = max(abs(eig(R)));
end

if N == 2
    tau12_abs = abs(tau_2);
elseif N == 3
    tau12_abs = tau_1;
    for jz = 1:z_num 
        tau12_abs(jz) = max(sqrt(abs(tau_2(jz).*(tau_2(jz)+tau_1(jz)))), ...
                            sqrt(abs(tau_2(jz).*(tau_2(jz)-tau_1(jz)))));
    end
elseif N == 4
    tau12_abs = tau_1;
    for jz = 1:z_num 
        r = tau_1(jz)/tau_2(jz);
        u = roots([1, 0, -2*r^2, -r^4]) + 1;
        tau12_abs(jz) = abs(tau_2(jz))*max(sqrt(abs(u)));
    end
else
     for jz = 1:z_num 
        tau12_abs(jz) = sqrt(abs(tau_1(jz))^2 + abs(tau_2(jz))^2);    
     end
end

figure(1);  
if nu == 1e-1
    semilogx(real(zz),rho_R,'r-',real(zz),tau12_abs,'k--','LineWidth',1.5,'MarkerSize',13);
    %hold on;
else
    semilogx(real(zz),rho_R,'b-',real(zz),tau12_abs,'k-.','LineWidth',1.5,'MarkerSize',13);
    hold off;
end
set(gca,'FontSize',19);
xlabel('$z (=\Delta t\lambda)$','Interpreter','latex','FontSize',22);
title(['$\theta=',num2str(theta),'$'],'Interpreter','latex','FontSize',22); 
leg = legend(['$\rho(\mathbf{R})$ for $\nu=',num2str(nu),'$'],['bound for $\nu=',num2str(nu),'$']);
set(leg,'fontsize',16,'interpreter','latex');
xlim([min(real(zz)),max(real(zz))]);
set(gca,'xtick',10.^(-3:3));